import React from 'react';
import './body.css';
class Body extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            imagen: props.url,
            descripcion: props.descrcipcionImagen,
            numero: props.numeroInicial
        };
    }
    numeroRandom = () => {
        this.setState({ numero: Math.round(Math.random() * (100 - 1) + 1) });
        }

    render() {
        return (
            <div className='body'>
                <img className='imgBody' src={this.state.imagen}></img>
                <p>{this.state.descripcion}</p>
                <button onClick={this.numeroRandom}>Cambiar Número</button>

                <h6>Número: {this.state.numero}</h6>
            </div>
        );
    }
} export default Body;