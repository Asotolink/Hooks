import React from 'react';
import './footer.css';
class Footer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            barraFooter: props.opciones
        };
    }

    render() {
        return (
            <div className='footer'>
                {this.state.barraFooter.map((valor)=> <p>{valor}</p>)}
            </div>
        );
    }
} export default Footer;