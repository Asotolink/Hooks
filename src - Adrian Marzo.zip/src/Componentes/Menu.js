import React from 'react';
import './menu.css';
class Menu extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            barraNav: props.opciones
        };
    }

    render() {
        return (
            <div className='menu'>
                {this.state.barraNav.map((valor)=> <p>{valor}</p>)}
            </div>
        );
    }
} export default Menu;