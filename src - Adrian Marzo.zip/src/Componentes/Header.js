import React from 'react';
import './header.css';
class Header extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            imagen: props.url
        };
    }
    render() {
        return (
            <div>
                <img className='imgHeader' src={this.state.imagen}></img>
            </div>
        );
    }
} export default Header;