import logo from './logo.svg';
import './App.css';


import Body from './Componentes/Body';
import Header from './Componentes/Header';
import Menu from './Componentes/Menu';
import Footer from './Componentes/Footer';

function App() {
  return (
    <div className="App">
      <Menu opciones={["Contactar", "Servicios", "Inicio"]}/>
      <Header url="https://www.zoopinto.es/wp-content/uploads/2021/12/pajaro-mascota.jpg"/>

      <div className='colocarBody'>
      <Body y url="https://static.fundacion-affinity.org/cdn/farfuture/PVbbIC-0M9y4fPbbCsdvAD8bcjjtbFc0NSP3lRwlWcE/mtime:1643275542/sites/default/files/los-10-sonidos-principales-del-perro.jpg" descrcipcionImagen="Una foto de un perro" numeroInicial="3" />

      <Body y url="https://img.europapress.es/fotoweb/fotonoticia_20171016171513_420.jpg" descrcipcionImagen="Una foto de un delfin" numeroInicial="5" />

      <Body y url="https://upload.wikimedia.org/wikipedia/commons/0/09/Polar_Bear_-_Alaska.jpg" descrcipcionImagen="Una foto de un oso polar" numeroInicial="1" />
      </div>

      <Footer opciones={["Sobre Nosotros", "Método de pagos", "Pruebas"]}/>
    </div>
  );
}

export default App;
