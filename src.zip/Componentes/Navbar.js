const Navbar = () =>
( 
    <div>
        <ul>
 <li>
        <a href={"/"}>Inicio</a>
    </li>
    <li>
        <a href={"/about-us"}>About us</a>
    </li>
    </ul>
    </div>

   
)

export default Navbar
