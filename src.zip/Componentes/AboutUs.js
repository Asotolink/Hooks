import { useEffect, useState } from "react"
import Navbar from "./Navbar";



// useEffect(()=>{
//     fetch
// })
const AboutUs = () =>{
    const {producto, setProductos} = useState([]);

return( 
    <div>
        <Navbar></Navbar>
        Hola
        <input type="email"></input>
        
    </div>

   
)}
export default AboutUs