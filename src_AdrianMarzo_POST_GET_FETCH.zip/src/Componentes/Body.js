import React from 'react';
import './body.css';
import Producto from './Producto';
class Body extends React.Component {
    constructor(props) {
        super(props);
        this.state = { data: [] };
        this.otroProducto = this.otroProducto.bind(this);
    }
    componentDidMount() {
        fetch('https://dummyjson.com/products'/* , {method: 'POST'} */)
            .then(response => response.json())
            .then(data => {
                this.setState({
                    data: data.products
                });
            })
            .catch(error => {
                console.log(error);
            });

    }

    otroProducto() {
        fetch('https://dummyjson.com/products/add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                title: 'Adrian Marzo',
                description: 'Objeto nuevo creado por mí',
                images: ['https://static.fundacion-affinity.org/cdn/farfuture/PVbbIC-0M9y4fPbbCsdvAD8bcjjtbFc0NSP3lRwlWcE/mtime:1643275542/sites/default/files/los-10-sonidos-principales-del-perro.jpg']
            })
        })
            .then(res => res.json())
            .then(data => {
                this.setState({
                    data2: data
                });
            })
    }




    render() {
        return (
            <div className='body'>

                {this.state.data.map((valor) => { return <Producto datos={valor} /> })}

                {this.state.data2 && <Producto datos={this.state.data2} />}
                <br></br>
                <button type='submit' onClick={this.otroProducto}>Añadir producto</button>
                <br></br>
            </div>
        );
    }
} export default Body;