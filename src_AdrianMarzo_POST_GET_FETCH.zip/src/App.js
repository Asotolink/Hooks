import './App.css';
import Body from './Componentes/Body';


function App() {
  return (
    <div className="App">
      <div className="container">
        <h1>PRODUCTOS</h1>
        <Body />
      </div>
    </div>
  );
}

export default App;
